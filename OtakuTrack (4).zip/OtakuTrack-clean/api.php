<?php
// ===== CONFIGURATION BASE DE DONNÉES =====
define('DB_HOST', 'sql211.infinityfree.com');
define('DB_USER', 'if0_42007210');
define('DB_PASS', 'fODcDIjAnvHwE');
define('DB_NAME', 'if0_42007210_osaku_track');

// ===== HEADERS =====
header('Content-Type: application/json; charset=utf-8');
// Autoriser GitHub Pages (et tout autre domaine si besoin)
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// ===== CONNEXION =====
function getDB() {
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    if ($conn->connect_error) {
        http_response_code(500);
        echo json_encode(['error' => 'Connexion échouée: ' . $conn->connect_error]);
        exit;
    }
    $conn->set_charset('utf8mb4');
    return $conn;
}

// ===== ROUTING =====
$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';

switch ($action) {
    case 'get_all':
        getAll();
        break;
    case 'save_all':
        saveAll();
        break;
    case 'status':
        echo json_encode(['ok' => true, 'message' => 'API OtakuTrack opérationnelle']);
        break;
    default:
        http_response_code(400);
        echo json_encode(['error' => 'Action inconnue']);
}

// ===== RÉCUPÉRER TOUTES LES DONNÉES =====
function getAll() {
    $db = getDB();

    $animes = [];
    $mangas = [];

    // Charger les animes
    $result = $db->query("SELECT * FROM animes ORDER BY title");
    while ($row = $result->fetch_assoc()) {
        $anime = [
            'id'           => $row['id'],
            'type'         => 'anime',
            'title'        => $row['title'],
            'poster'       => $row['poster'],
            'lastModified' => (int)$row['last_modified'],
            'seasons'      => []
        ];

        // Charger les saisons de cet anime
        $id = $db->real_escape_string($row['id']);
        $seasons = $db->query("SELECT * FROM seasons WHERE anime_id = '$id' ORDER BY sort_order");
        while ($s = $seasons->fetch_assoc()) {
            $anime['seasons'][] = [
                'name'    => $s['name'],
                'eps'     => (int)$s['eps'],
                'watched' => (int)$s['watched'],
                'epDur'   => (int)$s['ep_dur']
            ];
        }

        $animes[] = $anime;
    }

    // Charger les mangas
    $result = $db->query("SELECT * FROM mangas ORDER BY title");
    while ($row = $result->fetch_assoc()) {
        $mangas[] = [
            'id'           => $row['id'],
            'type'         => 'manga',
            'title'        => $row['title'],
            'total'        => (int)$row['total'],
            'read'         => (int)$row['tome_read'],
            'notes'        => $row['notes'],
            'poster'       => $row['poster'],
            'lastModified' => (int)$row['last_modified']
        ];
    }

    $db->close();
    echo json_encode(['animes' => $animes, 'mangas' => $mangas]);
}

// ===== SAUVEGARDER TOUTES LES DONNÉES =====
function saveAll() {
    $body = json_decode(file_get_contents('php://input'), true);
    if (!$body || !isset($body['animes']) || !isset($body['mangas'])) {
        http_response_code(400);
        echo json_encode(['error' => 'Données invalides']);
        return;
    }

    $db = getDB();

    // Transaction pour garantir l'intégrité
    $db->begin_transaction();

    try {
        // ---- ANIMES ----
        // Récupérer les IDs existants
        $existing = [];
        $res = $db->query("SELECT id FROM animes");
        while ($r = $res->fetch_assoc()) $existing[$r['id']] = true;

        $incomingIds = array_column($body['animes'], 'id');

        // Supprimer les animes qui ne sont plus dans la liste
        foreach ($existing as $eid => $_) {
            if (!in_array($eid, $incomingIds)) {
                $safe = $db->real_escape_string($eid);
                $db->query("DELETE FROM seasons WHERE anime_id = '$safe'");
                $db->query("DELETE FROM animes WHERE id = '$safe'");
            }
        }

        // Insérer ou mettre à jour chaque anime
        foreach ($body['animes'] as $anime) {
            $id           = $db->real_escape_string($anime['id'] ?? '');
            $title        = $db->real_escape_string($anime['title'] ?? '');
            $poster       = $db->real_escape_string($anime['poster'] ?? '');
            $lastModified = (int)($anime['lastModified'] ?? 0);

            if (isset($existing[$anime['id']])) {
                $db->query("UPDATE animes SET title='$title', poster='$poster', last_modified=$lastModified WHERE id='$id'");
            } else {
                $db->query("INSERT INTO animes (id, title, poster, last_modified) VALUES ('$id','$title','$poster',$lastModified)");
            }

            // Reconstruire les saisons (delete + insert)
            $db->query("DELETE FROM seasons WHERE anime_id = '$id'");
            foreach ($anime['seasons'] as $i => $s) {
                $name    = $db->real_escape_string($s['name'] ?? '');
                $eps     = (int)($s['eps'] ?? 0);
                $watched = (int)($s['watched'] ?? 0);
                $epDur   = (int)($s['epDur'] ?? 20);
                $db->query("INSERT INTO seasons (anime_id, sort_order, name, eps, watched, ep_dur)
                            VALUES ('$id', $i, '$name', $eps, $watched, $epDur)");
            }
        }

        // ---- MANGAS ----
        $existingM = [];
        $res = $db->query("SELECT id FROM mangas");
        while ($r = $res->fetch_assoc()) $existingM[$r['id']] = true;

        $incomingMIds = array_column($body['mangas'], 'id');
        foreach ($existingM as $eid => $_) {
            if (!in_array($eid, $incomingMIds)) {
                $safe = $db->real_escape_string($eid);
                $db->query("DELETE FROM mangas WHERE id = '$safe'");
            }
        }

        foreach ($body['mangas'] as $manga) {
            $id           = $db->real_escape_string($manga['id'] ?? '');
            $title        = $db->real_escape_string($manga['title'] ?? '');
            $total        = (int)($manga['total'] ?? 0);
            $read         = (int)($manga['read'] ?? 0);
            $notes        = $db->real_escape_string($manga['notes'] ?? '');
            $poster       = $db->real_escape_string($manga['poster'] ?? '');
            $lastModified = (int)($manga['lastModified'] ?? 0);

            if (isset($existingM[$manga['id']])) {
                $db->query("UPDATE mangas SET title='$title', total=$total, tome_read=$read, notes='$notes', poster='$poster', last_modified=$lastModified WHERE id='$id'");
            } else {
                $db->query("INSERT INTO mangas (id, title, total, tome_read, notes, poster, last_modified)
                            VALUES ('$id','$title',$total,$read,'$notes','$poster',$lastModified)");
            }
        }

        $db->commit();
        echo json_encode(['ok' => true]);
    } catch (Exception $e) {
        $db->rollback();
        http_response_code(500);
        echo json_encode(['error' => $e->getMessage()]);
    }

    $db->close();
}
