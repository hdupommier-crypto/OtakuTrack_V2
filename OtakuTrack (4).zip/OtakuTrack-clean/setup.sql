-- ============================================================
-- OtakuTrack — Initialisation base de données MySQL
-- Serveur : noitulosqzhip.mysql.db
-- Base    : noitulosqzhip
-- ============================================================

-- Animes
CREATE TABLE IF NOT EXISTS animes (
    id            VARCHAR(20)   NOT NULL PRIMARY KEY,
    title         VARCHAR(255)  NOT NULL,
    poster        TEXT          DEFAULT '',
    last_modified BIGINT        DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Saisons (liées aux animes)
CREATE TABLE IF NOT EXISTS seasons (
    id          INT           AUTO_INCREMENT PRIMARY KEY,
    anime_id    VARCHAR(20)   NOT NULL,
    sort_order  INT           DEFAULT 0,
    name        VARCHAR(100)  DEFAULT '',
    eps         INT           DEFAULT 0,
    watched     INT           DEFAULT 0,
    ep_dur      INT           DEFAULT 20,
    FOREIGN KEY (anime_id) REFERENCES animes(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Mangas
CREATE TABLE IF NOT EXISTS mangas (
    id            VARCHAR(20)   NOT NULL PRIMARY KEY,
    title         VARCHAR(255)  NOT NULL,
    total         INT           DEFAULT 0,
    tome_read     INT           DEFAULT 0,
    notes         TEXT          DEFAULT '',
    poster        TEXT          DEFAULT '',
    last_modified BIGINT        DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
